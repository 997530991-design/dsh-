# MiniEval 评分网关 · 使用说明（v1.4.5）

在 DeepSeek Harness（DSH）内部提供一个 **OpenAI 兼容端点**。
经过这个端点的对话，模型回复会先由评分打分，按放行线决定返回哪一条。

---

## 一、安装

### 方式 A：从目录安装（推荐）

把 `minieval-gateway/` 整个目录交给插件管理器，或：

```
dsh plugin --profile web add <你解压到的目录>/minieval-gateway
```

### 方式 B：从压缩包安装

```bash
dsh plugin --profile web add minieval-gateway-1.4.5.tgz
```

安装后 **必须重启 DSH**。

---

## 二、配置插件

重启后打开：**设置 → MiniEval 评分网关**

### 1. 输出模型（生成回复）

| 字段 | 填什么 |
|---|---|
| 模型 | `deepseek-flash` 或 `deepseek-v4-pro` |
| API 地址 | `https://api.deepseek.com` |
| API key | 你的 DeepSeek key（必填） |

保存后右侧应显示绿色 **已保存**。

### 2. 评分模型（给回复打分）

| 字段 | 填什么 |
|---|---|
| 评分模型 | 建议 `deepseek-flash`（快、便宜） |
| 评分地址 | 留空则与输出模型相同 |
| 评分 key | 留空则共用输出模型的 key |
| 主流预设 | 选中后自动填模型 + 地址 |

### 3. 过滤规则

| 字段 | 含义 |
|---|---|
| 放行线 | 0–4，达到这个分数才放行 |
| 总次数上限 | 不达标就重新生成，最多几次（1–20） |

### 4. 评分标准

格式：`分数|标签|定义`，一行一条。

**默认是空的**，需要你自己填。留空时评分给不出分类，所有回复按 0 分处理。

每条用竖线分段：分数（0–4）、标签（小写英文）、定义（给评分看的说明）。

### 5. 请求改写（三个开关）

| 开关 | 作用 |
|---|---|
| 替换系统提示词 | 用插件里的「系统提示词」替换请求里的 system |
| 剥离 system-reminder | 删掉请求里的 `<system-reminder>` 块 |
| 剥离工具定义 | 不把 tools 发给模型（模型只能纯聊天） |

---

## 三、在 DSH 里接入

**设置 → 模型 → 自定义模型 API**

| 字段 | 填什么 |
|---|---|
| Provider ID | `minieval` |
| 显示名称 | `MiniEval 过滤` |
| API 地址 | `http://127.0.0.1:3080/minieval/v1` |
| API 协议 | `OpenAI Chat Completions` |
| API 密钥 | 随便填（网关不校验） |

**格式注意：**

- 地址**结尾不要加斜杠**
- 地址**不要带** `/chat/completions`（客户端会自动拼）
- 端口必须是 **3080**（DSH 自己的端口）

填完在模型选择器里切到 **MiniEval 过滤**，对话才会经过评分。

---

## 四、运行效果

```
你发一句
   ↓
网关改写请求（剥工具 / 剥 reminder / 换 system）
   ↓
生成第 1 条 → 评分打分
   ├─ 达到放行线 → 返回这条
   └─ 不达标 → 重新生成，最多「总次数上限」次
        ↓ 全部不达标
      返回分数最高的那条（原文不动）
```

**输入框上方**会显示：

```
第 2 次重试，3 分
```

---

## 五、接口（也可直接用 curl 调）

```bash
curl -sS http://127.0.0.1:3080/minieval/v1/chat/completions \
  -H 'Content-Type: application/json' \
  -d '{"model":"deepseek-flash","messages":[{"role":"user","content":"你好"}]}'
```

返回里带判分元信息：

```json
{
  "choices": [{"message": {"content": "..."}}],
  "minieval": {"score": 3, "passed": false, "target": 4, "attemptsUsed": 2}
}
```

| 字段 | 含义 |
|---|---|
| `score` | 评分给的分数（0–4） |
| `passed` | 是否达到放行线 |
| `target` | 当时的放行线 |
| `attemptsUsed` | 第几次尝试拿到的 |

### 其他端点

| 端点 | 作用 |
|---|---|
| `GET /minieval/v1/models` | 列出模型 |
| `GET/POST /minieval/api/config` | 读 / 写配置 |
| `GET /minieval/api/events` | 实时判分事件流（SSE） |

---

## 六、配置存在哪

```
~/.dsh/minieval-gateway.json      ← 插件页保存的值
插件 cordis.patch.yml 的 config   ← 默认值
```

页面保存的值优先。

---

## 七、常见问题

| 现象 | 原因 | 解决 |
|---|---|---|
| `Unexpected token 'A'` | 上游返回 401 的 HTML | 填 API key |
| 响应 502 | key 无效或地址错 | 检查 key / 地址 |
| 输入框上方没有分数 | 请求没走网关 | 切换模型到 MiniEval 过滤 |
| 回复很慢 | 总次数上限太大 | 调小到 3–5 |
| 设置页不出现 | 没重启 | 重启 DSH |

---

## 八、版本

**v1.4.5**
